module.exports = {
  token: '619304627869-riMqFa0ogI',
  mongo_url:"mongodb://mongo:cHU0wtainers-us-west-137.ra615",
    admins: [5908965726],
    curr:'USDT',
    lvl : [18,0,0],
    minAmount:[100,9999,99999],
    fakestatistics:{
        totalUsers: 0,
        totalDeposits: 0,
        totalInvests: 0,
        totalWithdrawals: 0
      },
      CUsername:"gigigf",
      PrivateKey: "202af84ec5012c7fd59618aaaa9354bdc20d03f7194172a522e3a76deb08",
      USDT_RECIVER: "TKjKd4aJVQwhshXh6BT6HWpDheWyPhP",
    appname: "https://tetherron.up.railway.app",
    aboutmsg: "👋 Welcome to our Platform!\n\nWe are a team of experienced traders and cryptocurrency experts who have come together to create a platform that allows you to easily invest your 💰TRX and earn attractive returns.\n\n💻 Our platform is built on cutting-edge technology, ensuring a seamless investment experience with real-time updates on your portfolio's performance.\n\n🔒 We use advanced security measures, such as two-factor authentication and SSL encryption, to protect your investments and personal information from unauthorized access and theft.\n\n📈 At our platform, we believe in transparency and honesty. That's why we provide detailed information on our investment plans, so you can make informed decisions and monitor your returns. We also offer a dedicated support team to assist you with any questions or concerns you may have.\n\n💡 Whether you're a seasoned investor or new to the world of cryptocurrency, our team of experts is here to help you navigate the market and maximize your returns. We offer a variety of investment options, including mining and staking income, so you can choose the strategy that works best for you.\n\nThank you for choosing us. We boldly look forward to helping you achieve your financial goals! 💪",
    deposit_text:`👋 Welcome to our Investment Bot!

💰 Ready to earn some passive income? Choose from our 1 investment option:

🚀 *Daily Income:*
- Earn *2% daily* for your investment in USDT (TRC20). Total return is capped at *300%*.

⚠️ Please note: Deposits less than *50 USDT* will not be accepted.

✅ Ready to invest? Simply send USDT (TRC20) to our deposit address and start earning!`  }

